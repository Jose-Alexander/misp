# Design System Specification: The Academic Curator

## 1. Overview & Creative North Star
The design system for this university job board is defined by a Creative North Star we call **"The Digital Curator."** 

Moving away from the cluttered, utilitarian aesthetic of traditional job boards, this system treats career opportunities as curated exhibits. We avoid the "template" look by utilizing intentional white space, sophisticated tonal layering, and an editorial typography scale. The goal is to provide students with a sense of institutional prestige ("Academic") blended with the fluid, effortless movement of high-end modern software ("Accessible"). By prioritizing breathing room and removing unnecessary structural lines, we create a high-focus environment that reduces "search fatigue" and empowers the student’s professional journey.

---

## 2. Colors: Tonal Depth over Structural Lines
The palette is anchored in trustworthy, authoritative blues (`primary`) and expansive, airy neutrals (`surface`). 

### The "No-Line" Rule
To achieve a premium editorial feel, **1px solid borders are strictly prohibited for sectioning.** Boundaries must be defined solely through background color shifts or subtle tonal transitions. For example, a main content area using `surface-container-low` (#f4f2fb) should sit directly against a `surface` (#fbf8fe) background without a stroke.

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers—like stacked sheets of fine vellum.
*   **Lowest Layer:** `surface` (#fbf8fe) as the base canvas.
*   **Secondary Layer:** `surface-container-low` (#f4f2fb) for grouping related content sections.
*   **Action Layer:** `surface-container-lowest` (#ffffff) for the most interactive elements, like job cards or profile modules, to make them "pop" through lightness rather than shadows.

### The "Glass & Gradient" Rule
To inject "soul" into the academic framework:
*   **Glassmorphism:** For floating headers or bottom navigation bars, use `surface` at 80% opacity with a `20px` backdrop-blur. This allows content to bleed through, softening the interface.
*   **Signature Textures:** Main CTAs (like "Apply Now") should utilize a subtle linear gradient from `primary` (#525d8c) to `primary-dim` (#46517f) at a 135-degree angle. This provides a tactile, "pressable" quality that flat colors lack.

---

## 3. Typography: The Editorial Voice
We use **Inter** for its neutral, highly legible, and professional demeanor. The hierarchy is designed to guide the eye through dense job descriptions with ease.

*   **The Display Scale:** Use `display-md` (2.75rem) for welcome screens or empty states. This creates a bold, "poster-like" entry point.
*   **The Headline Scale:** `headline-sm` (1.5rem) should be used for job titles in detail views. It commands authority without overwhelming the mobile screen.
*   **The Label Scale:** `label-md` (0.75rem) in `on-surface-variant` (#5e5e68) is reserved for metadata (e.g., "Posted 2 days ago" or "Full-time"). 
*   **The Body Scale:** `body-lg` (1rem) is the standard for job descriptions, ensuring maximum readability for long-form text.

---

## 4. Elevation & Depth: Tonal Layering
Traditional drop shadows create "visual mud." This system relies on **Tonal Layering** to convey hierarchy.

*   **The Layering Principle:** Depth is achieved by "stacking." Place a `surface-container-lowest` card on a `surface-container-low` section to create a soft, natural lift.
*   **Ambient Shadows:** If a "floating" effect is required (e.g., a FAB or a modal), shadows must be extra-diffused. Use a 24px blur, 0px offset, and 6% opacity of the `on-surface` color (#31323b).
*   **The "Ghost Border" Fallback:** If a border is essential for accessibility in high-glare environments, use a **Ghost Border**: `outline-variant` (#b1b1bc) at 15% opacity. Never use 100% opaque lines.

---

## 5. Components

### Cards & Job Listings
*   **Style:** No borders. Use `surface-container-lowest` (#ffffff) for the card body. 
*   **Spacing:** Use a generous `1.5rem` padding to give job titles and company logos room to breathe. 
*   **Constraint:** Forbid the use of divider lines between items. Use `1rem` of vertical white space to separate individual job cards.

### Buttons
*   **Primary:** Gradient of `primary` to `primary-dim`. Roundedness: `lg` (0.5rem).
*   **Secondary:** `secondary-container` (#dee1f9) background with `on-secondary-container` (#4d5164) text.
*   **Tertiary:** No background. Use `primary` text. These should feel like high-end text links in a journal.

### Input Fields
*   **Style:** Avoid the "box" look. Use a filled style with `surface-container-high` (#e8e7f1) and a `0.25rem` bottom radius. 
*   **States:** Upon focus, transition the background to `surface-container-highest` (#e2e1ed) and add a subtle `2px` underline in `primary`.

### Chips (Filters/Skills)
*   **Style:** Use `surface-variant` (#e2e1ed) for unselected states and `primary` for selected states. 
*   **Rounding:** Always use `full` (9999px) roundedness to contrast with the more structured `lg` cards.

### Navigation
*   **Style:** A "Glassmorphic" bottom bar. Use `surface` at 85% opacity with a `32px` backdrop blur. 
*   **Indicator:** An active state is indicated by a subtle `tertiary-container` (#efcffe) pill behind the icon, rather than a color change alone.

---

## 6. Do’s and Don’ts

### Do:
*   **Use Asymmetry:** Place company logos slightly off-center or use varied padding to create a bespoke, editorial layout.
*   **Prioritize Type:** Let the `title-lg` and `body-lg` do the heavy lifting of organizing information.
*   **Embrace Whitespace:** If a screen feels "empty," it’s likely working. Avoid the urge to fill every pixel with a line or a box.

### Don’t:
*   **Don't use 100% Black:** Always use `on-surface` (#31323b) for text to maintain a sophisticated, soft-contrast look.
*   **Don't use Default Shadows:** Standard shadows feel like "web 2.0." Stick to tonal shifts.
*   **Don't use Dividers:** If you need to separate two pieces of information, use a background color change or a `1rem` gap. Dividers are visual clutter.